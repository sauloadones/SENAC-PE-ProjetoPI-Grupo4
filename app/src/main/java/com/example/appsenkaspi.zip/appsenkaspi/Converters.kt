package com.example.appsenkaspi

import androidx.room.TypeConverter

import java.util.Date

class Converters {

    @TypeConverter
    fun fromTimestamp(value: Long?): Date? = value?.let { Date(it) }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? = date?.time

    @TypeConverter
    fun fromCargo(cargo: Cargo): String = cargo.name.lowercase()
    @TypeConverter
    fun toCargo(value: String): Cargo = try {
        Cargo.valueOf(value.uppercase())
    } catch (e: IllegalArgumentException) {
        Cargo.APOIO
    }

    @TypeConverter
    fun fromStatusPilar(status: StatusPilar): String = status.name.lowercase()
    @TypeConverter
    fun toStatusPilar(value: String): StatusPilar = try {
        StatusPilar.valueOf(value.uppercase())
    } catch (e: IllegalArgumentException) {
        StatusPilar.VENCIDO
    }

    @TypeConverter
    fun fromStatusAcao(status: StatusAcao): String = status.name.lowercase()
    @TypeConverter
    fun toStatusAcao(value: String): StatusAcao = try {
        StatusAcao.valueOf(value.uppercase())
    } catch (e: IllegalArgumentException) {
        StatusAcao.PLANEJADA
    }

    @TypeConverter
    fun fromStatusAtividade(status: StatusAtividade): String = status.name.lowercase()
    @TypeConverter
    fun toStatusAtividade(value: String): StatusAtividade = try {
        StatusAtividade.valueOf(value.uppercase())
    } catch (e: IllegalArgumentException) {
        StatusAtividade.PENDENTE
    }

    @TypeConverter
    fun fromPrioridade(prioridade: PrioridadeAtividade): String = prioridade.name.lowercase()
    @TypeConverter
    fun toPrioridade(value: String): PrioridadeAtividade = try {
        PrioridadeAtividade.valueOf(value.uppercase())
    } catch (e: IllegalArgumentException) {
        PrioridadeAtividade.MEDIA
    }

    @TypeConverter
    fun fromStatusRequisicao(status: StatusRequisicao): String = status.name.lowercase()
    @TypeConverter
    fun toStatusRequisicao(value: String): StatusRequisicao = try {
        StatusRequisicao.valueOf(value.uppercase())
    } catch (e: IllegalArgumentException) {
        StatusRequisicao.PENDENTE
    }

    @TypeConverter
    fun fromTipoRequisicao(tipo: TipoRequisicao): String = tipo.name.lowercase()
    @TypeConverter
    fun toTipoRequisicao(value: String): TipoRequisicao = try {
        TipoRequisicao.valueOf(value.uppercase())
    } catch (e: IllegalArgumentException) {
        TipoRequisicao.CONFIRMACAO_ATIVIDADE
    }

    @TypeConverter
    fun fromStatusNotificacao(status: StatusNotificacao): String = status.name.lowercase()
    @TypeConverter
    fun toStatusNotificacao(value: String): StatusNotificacao = try {
        StatusNotificacao.valueOf(value.uppercase())
    } catch (e: IllegalArgumentException) {
        StatusNotificacao.NOVA
    }

    @TypeConverter
    fun fromTipoDeNotificacao(tipo: TipoDeNotificacao): String = tipo.name.lowercase()
    @TypeConverter
    fun toTipoDeNotificacao(value: String): TipoDeNotificacao = try {
        TipoDeNotificacao.valueOf(value.uppercase())
    } catch (e: IllegalArgumentException) {
        TipoDeNotificacao.PEDIDO_CRIACAO_ACAO
    }
}
