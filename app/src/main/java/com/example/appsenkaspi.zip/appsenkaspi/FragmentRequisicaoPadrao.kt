package com.example.appsenkaspi

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.bumptech.glide.Glide
import com.example.appsenkaspi.databinding.FragmentRequisicaoPadraoBinding
import java.text.SimpleDateFormat
import java.util.*

class FragmentRequisicaoPadrao : Fragment() {

    private var _binding: FragmentRequisicaoPadraoBinding? = null
    private val binding get() = _binding!!

    private val requisicaoViewModel: RequisicaoViewModel by activityViewModels()

    private lateinit var notificacao: NotificacaoComRequisicaoEFuncionario

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRequisicaoPadraoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        arguments?.getSerializable("notificacao")?.let {
            notificacao = it as NotificacaoComRequisicaoEFuncionario
        } ?: run {
            Toast.makeText(requireContext(), "Erro ao carregar requisição", Toast.LENGTH_SHORT).show()
            parentFragmentManager.popBackStack()
            return
        }

        preencherCampos(notificacao)

        binding.btnAceitar.setOnClickListener {
            requisicaoViewModel.aceitarRequisicao(notificacao.requisicao.id)
            Toast.makeText(requireContext(), "Requisição aceita", Toast.LENGTH_SHORT).show()
            parentFragmentManager.popBackStack()
        }

        binding.btnRecusar.setOnClickListener {
            requisicaoViewModel.recusarRequisicao(notificacao.requisicao.id)
            Toast.makeText(requireContext(), "Requisição recusada", Toast.LENGTH_SHORT).show()
            parentFragmentManager.popBackStack()
        }
    }

    private fun preencherCampos(notificacao: NotificacaoComRequisicaoEFuncionario) {
        val dados = notificacao.dadosAcaoOuAtividade

        when (dados) {
            is DadosRequisicao.DadosAtividade -> {
                binding.textTituloRequisicao.text = "Requisição de ${notificacao.requisicao.tipo.name.lowercase().replace("_", " ")} para o Pilar ${dados.nomePilar}"
                binding.textNome.text = dados.nome
                binding.textDescricao.text = dados.descricao

                // Prioridade
                binding.textPrioridade.visibility = View.VISIBLE
                binding.textPrioridade.text = when (dados.prioridade) {
                    PrioridadeAtividade.ALTA -> "Prioridade Alta"
                    PrioridadeAtividade.MEDIA -> "Prioridade Média"
                    PrioridadeAtividade.BAIXA -> "Prioridade Baixa"
                }

                // Datas
                val sdf = SimpleDateFormat("dd 'de' MMMM 'de' yyyy", Locale("pt", "BR"))
                binding.textDataInicio.apply {
                    text = "Início: ${sdf.format(dados.dataInicio)}"
                    visibility = View.VISIBLE
                }
                binding.textDataPrazo.apply {
                    text = "Prazo: ${sdf.format(dados.dataPrazo)}"
                    visibility = View.VISIBLE
                }

                // Responsáveis
                preencherResponsaveis(dados.responsaveis)
            }

            is DadosRequisicao.DadosAcao -> {
                binding.textTituloRequisicao.text = "Requisição de ${notificacao.requisicao.tipo.name.lowercase().replace("_", " ")} para o Pilar ${dados.nomePilar}"
                binding.textNome.text = dados.nome
                binding.textDescricao.text = dados.descricao

                // Oculta campos que não se aplicam
                binding.textPrioridade.visibility = View.GONE
                binding.textDataInicio.visibility = View.GONE
                binding.textDataPrazo.visibility = View.GONE

                // Responsáveis
                preencherResponsaveis(dados.responsaveis)
            }

            else -> {
                Toast.makeText(requireContext(), "Tipo de requisição não reconhecido", Toast.LENGTH_SHORT).show()
                parentFragmentManager.popBackStack()
            }
        }
    }

    private fun preencherResponsaveis(responsaveis: List<FuncionarioEntity>) {
        binding.containerResponsaveis.removeAllViews()
        val dimensao = resources.getDimensionPixelSize(R.dimen.tamanho_foto_responsavel)

        responsaveis.forEach { funcionario ->
            val foto = de.hdodenhof.circleimageview.CircleImageView(requireContext()).apply {
                layoutParams = ViewGroup.MarginLayoutParams(dimensao, dimensao).apply {
                    marginEnd = 12
                }
                borderWidth = 2
                borderColor = android.graphics.Color.WHITE
            }

            Glide.with(this)
                .load(funcionario.fotoPerfil)
                .placeholder(R.drawable.ic_person)
                .into(foto)

            binding.containerResponsaveis.addView(foto)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
