package com.example.appsenkaspi

import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query


import androidx.lifecycle.LiveData
import androidx.room.*



@Dao
interface NotificacaoDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun inserir(notificacao: NotificacaoEntity)

    @Update
    suspend fun atualizar(notificacao: NotificacaoEntity)

    @Delete
    suspend fun deletar(notificacao: NotificacaoEntity)

    @Query("SELECT * FROM notificacoes WHERE id = :id")
    suspend fun buscarPorId(id: Int): NotificacaoEntity?

    @Transaction
    @Query("SELECT * FROM notificacoes ORDER BY dataCriacao DESC")
    fun getNotificacoesCompletas(): LiveData<List<NotificacaoComRequisicaoEFuncionario>>



    @Query("DELETE FROM notificacoes WHERE status = 'ARQUIVIDA'")
    suspend fun deletarArquivadas()

    @Transaction
    @Query("SELECT * FROM notificacoes WHERE destinatarioId = :destinatarioId ORDER BY dataCriacao DESC")
    fun getNotificacoesCompletasPorDestinatario(destinatarioId: Int): LiveData<List<NotificacaoComRequisicaoEFuncionario>>

    @Transaction
    @Query("SELECT * FROM notificacoes WHERE id = :idNotificacao")
    fun getNotificacaoCompletaPorId(idNotificacao: Int): LiveData<NotificacaoComRequisicaoEFuncionario>

    @Query("UPDATE notificacoes SET status = :status WHERE id = :id")
    fun atualizarStatus(id: Int, status: String)

    @Transaction
    @Query("SELECT * FROM notificacoes WHERE id = :id")
    suspend fun getCompletaPorId(id: Int): NotificacaoComRequisicaoEFuncionario





}


