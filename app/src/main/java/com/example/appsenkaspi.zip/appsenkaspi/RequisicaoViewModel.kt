package com.example.appsenkaspi

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.appsenkaspi.Converters.StatusRequisicao
import com.example.appsenkaspi.Converters.TipoRequisicao
import kotlinx.coroutines.launch
import java.util.Date

class RequisicaoViewModel(application: Application) : AndroidViewModel(application) {

    private val requisicaoDao = AppDatabase.getDatabase(application).requisicaoDao()

    val todasRequisicoes: LiveData<List<RequisicaoEntity>> = requisicaoDao.listarTodas()

    fun listarPorStatus(status: StatusRequisicao): LiveData<List<RequisicaoEntity>> =
        requisicaoDao.listarPorStatus(status)

    fun listarPorTipo(tipo: TipoRequisicao): LiveData<List<RequisicaoEntity>> =
        requisicaoDao.listarPorTipo(tipo)

    fun listarPorSolicitante(funcionarioId: Int): LiveData<List<RequisicaoEntity>> =
        requisicaoDao.listarPorSolicitante(funcionarioId)

    fun inserir(requisicao: RequisicaoEntity) = viewModelScope.launch {
        requisicaoDao.inserir(requisicao)
    }

    fun atualizar(requisicao: RequisicaoEntity) = viewModelScope.launch {
        requisicaoDao.atualizar(requisicao)
    }

    fun deletar(requisicao: RequisicaoEntity) = viewModelScope.launch {
        requisicaoDao.deletar(requisicao)
    }
    fun aceitarRequisicao(requisicaoId: Int) = viewModelScope.launch {
        requisicaoDao.atualizarStatus(requisicaoId, StatusRequisicao.APROVADA)

        val requisicao = requisicaoDao.buscarPorId(requisicaoId)
        requisicao?.let {
            val notificacao = NotificacaoEntity(
                titulo = "Requisição Aprovada",
                mensagem = "Sua requisição de ${it.tipo.name.lowercase().replace("_", " ")} foi aprovada.",
                lida = false,
                dataCriacao = Date(),
                requisicaoId = it.id,
                remetenteId = it.idDestinatario ?: 0,
                destinatarioId = it.idSolicitante
            )
            AppDatabase.getDatabase(getApplication()).notificacaoDao().inserir(notificacao)
        }
    }

    fun recusarRequisicao(requisicaoId: Int) = viewModelScope.launch {
        requisicaoDao.atualizarStatus(requisicaoId, StatusRequisicao.REJEITADA)

        val requisicao = requisicaoDao.buscarPorId(requisicaoId)
        requisicao?.let {
            val notificacao = NotificacaoEntity(
                titulo = "Requisição Recusada",
                mensagem = "Sua requisição de ${it.tipo.name.lowercase().replace("_", " ")} foi recusada.",
                lida = false,
                dataCriacao = Date(),
                requisicaoId = it.id,
                remetenteId = it.idDestinatario ?: 0,
                destinatarioId = it.idSolicitante
            )
            AppDatabase.getDatabase(getApplication()).notificacaoDao().inserir(notificacao)
        }
    }

}
