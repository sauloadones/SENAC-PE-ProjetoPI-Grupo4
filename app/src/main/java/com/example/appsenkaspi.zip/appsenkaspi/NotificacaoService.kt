package com.example.appsenkaspi.services

import com.example.appsenkaspi.AppDatabase

import com.example.appsenkaspi.NotificacaoEntity
import com.example.appsenkaspi.RequisicaoEntity


import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.*



import android.content.Context
import com.example.appsenkaspi.StatusNotificacao
import com.example.appsenkaspi.TipoDeNotificacao
import com.example.appsenkaspi.TipoRequisicao


object NotificacaoService {

    /**
     * Gera uma notificação para o Coordenador ao criar uma requisição.
     */
    suspend fun gerarNotificacaoAoCriarRequisicao(
        context: Context,
        requisicao: RequisicaoEntity
    ) = withContext(Dispatchers.IO) {
        val db = AppDatabase.getDatabase(context)
        val coordenadorId = db.funcionarioDao().buscarTodos()
            .firstOrNull { it.cargo.name == "COORDENADOR" }?.id

        val tipoNotificacao = when (requisicao.tipo) {
            TipoRequisicao.CRIACAO_ACAO -> TipoDeNotificacao.PEDIDO_CRIACAO_ACAO
            TipoRequisicao.CRIACAO_ATIVIDADE -> TipoDeNotificacao.PEDIDO_CRIACAO_ATIVIDADE
            TipoRequisicao.EDICAO_ACAO -> TipoDeNotificacao.PEDIDO_EDICAO_ACAO
            TipoRequisicao.EDICAO_ATIVIDADE -> TipoDeNotificacao.PEDIDO_EDICAO_ATIVIDADE
            TipoRequisicao.CONFIRMACAO_ATIVIDADE -> TipoDeNotificacao.PEDIDO_CONFIRMACAO_ATIVIDADE
        }

        val notificacao = NotificacaoEntity(
            tipo = tipoNotificacao,
            mensagem = "Nova solicitação pendente para análise.",
            remetenteId = requisicao.idSolicitante,
            destinatarioId = coordenadorId,
            requisicaoId = requisicao.id,
            atividadeId = when (requisicao.tipo) {
                TipoRequisicao.CRIACAO_ATIVIDADE,
                TipoRequisicao.EDICAO_ATIVIDADE,
                TipoRequisicao.CONFIRMACAO_ATIVIDADE -> requisicao.idReferencia
                else -> null
            },
            acaoId = when (requisicao.tipo) {
                TipoRequisicao.CRIACAO_ACAO,
                TipoRequisicao.EDICAO_ACAO -> requisicao.idReferencia
                else -> null
            },
            status = StatusNotificacao.NAO_LIDA,
            dataCriacao = Date()
        )

        db.notificacaoDao().inserir(notificacao)
    }

    /**
     * Gera uma notificação para o Apoio quando o Coordenador aprova uma requisição.
     */
    suspend fun gerarNotificacaoAoAprovarRequisicao(
        context: Context,
        requisicao: RequisicaoEntity,
        tipoDeResposta: TipoDeNotificacao
    ) = withContext(Dispatchers.IO) {
        val db = AppDatabase.getDatabase(context)
        val coordenadorId = db.funcionarioDao().buscarTodos()
            .firstOrNull { it.cargo.name == "COORDENADOR" }?.id

        val notificacao = NotificacaoEntity(
            tipo = tipoDeResposta,
            mensagem = "Sua solicitação foi aprovada.",
            remetenteId = coordenadorId,
            destinatarioId = requisicao.idSolicitante,
            requisicaoId = requisicao.id,
            atividadeId = when (requisicao.tipo) {
                TipoRequisicao.CRIACAO_ATIVIDADE,
                TipoRequisicao.EDICAO_ATIVIDADE,
                TipoRequisicao.CONFIRMACAO_ATIVIDADE -> requisicao.idReferencia
                else -> null
            },
            acaoId = when (requisicao.tipo) {
                TipoRequisicao.CRIACAO_ACAO,
                TipoRequisicao.EDICAO_ACAO -> requisicao.idReferencia
                else -> null
            },
            status = StatusNotificacao.NAO_LIDA,
            dataCriacao = Date()
        )

        db.notificacaoDao().inserir(notificacao)
    }
}

