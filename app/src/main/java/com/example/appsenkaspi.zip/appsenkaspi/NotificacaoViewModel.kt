package com.example.appsenkaspi

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope

import com.example.appsenkaspi.relations.NotificacaoComRequisicaoEFuncionario
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotificacaoViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val notificacaoDao = db.notificacaoDao()
    private val requisicaoDao = db.requisicaoDao()
    private val funcionarioDao = db.funcionarioDao()
    private val acaoDao = db.acaoDao()
    private val atividadeDao = db.atividadeDao()
    private val pilarDao = db.pilarDao()
    private val acaoFuncionarioDao = db.acaoFuncionarioDao()
    private val atividadeFuncionarioDao = db.atividadeFuncionarioDao()

    fun getNotificacoesDoDestinatario(destinatarioId: Int): LiveData<List<NotificacaoComRequisicaoEFuncionario>> {
        return notificacaoDao.getNotificacoesCompletasPorDestinatario(destinatarioId)
    }

    fun aprovarRequisicao(
        requisicaoId: Int,
        novoStatus: StatusRequisicao,
        notificacao: NotificacaoEntity,
        idCoordenador: Int
    ) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                requisicaoDao.atualizarStatus(requisicaoId, novoStatus.name.lowercase())
                notificacaoDao.atualizarStatus(notificacao.id, StatusNotificacao.LIDA.name.lowercase())

                val tipoResposta = when (notificacao.tipo) {
                    TipoDeNotificacao.PEDIDO_CRIACAO_ATIVIDADE -> TipoDeNotificacao.CRIACAO_ATIVIDADE_ACEITA
                    TipoDeNotificacao.PEDIDO_CRIACAO_ACAO -> TipoDeNotificacao.CRIACAO_ACAO_ACEITA
                    TipoDeNotificacao.PEDIDO_EDICAO_ATIVIDADE -> TipoDeNotificacao.EDICAO_ATIVIDADE_ACEITA
                    TipoDeNotificacao.PEDIDO_EDICAO_ACAO -> TipoDeNotificacao.EDICAO_ACAO_ACEITA
                    TipoDeNotificacao.PEDIDO_CONFIRMACAO_ATIVIDADE -> TipoDeNotificacao.CONFIRMACAO_ATIVIDADE_ACEITA
                    else -> return@withContext
                }

                val mensagem = when (novoStatus) {
                    StatusRequisicao.APROVADA -> "Sua solicitação foi aprovada."
                    StatusRequisicao.REJEITADA -> "Sua solicitação foi recusada."
                    else -> "Sua solicitação foi processada."
                }

                val novaNotificacao = NotificacaoEntity(
                    tipo = tipoResposta,
                    mensagem = mensagem,
                    remetenteId = idCoordenador,
                    destinatarioId = notificacao.remetenteId,
                    requisicaoId = requisicaoId,
                    atividadeId = notificacao.atividadeId,
                    acaoId = notificacao.acaoId,
                    status = StatusNotificacao.NOVA
                )

                notificacaoDao.inserir(novaNotificacao)
            }
        }
    }

    fun buscarNotificacaoCompletaPorId(id: Int): LiveData<NotificacaoComRequisicaoEFuncionario> {
        val resultado = MutableLiveData<NotificacaoComRequisicaoEFuncionario>()

        viewModelScope.launch {
            val notificacao = notificacaoDao.getCompletaPorId(id)

            val dados = when (notificacao.requisicao.tipo) {
                TipoRequisicao.CRIACAO_ACAO, TipoRequisicao.EDICAO_ACAO -> {
                    val acao = acaoDao.getById(notificacao.requisicao.idReferencia ?: return@launch)
                    val pilar = pilarDao.getById(acao.pilarId)
                    val responsaveis = acaoFuncionarioDao.getResponsaveisByAcaoId(acao.id)

                    DadosRequisicao.DadosAcao(
                        nome = acao.nome,
                        descricao = acao.descricao,
                        prazoFormatado = formatarData(acao.dataPrazo),
                        nomePilar = pilar.nome,
                        responsaveis = responsaveis
                    )
                }

                TipoRequisicao.CONFIRMACAO_ATIVIDADE, TipoRequisicao.EDICAO_ATIVIDADE -> {
                    val atividade = atividadeDao.getById(notificacao.requisicao.idReferencia ?: return@launch)

                    // agora buscar a ação relacionada
                    val acao = acaoDao.getById(atividade.acaoId)

                    // e depois o pilar dessa ação
                    val pilar = pilarDao.getById(acao.pilarId)

                    val responsaveis = atividadeFuncionarioDao.getResponsaveisByAtividadeId(atividade.id)

                    DadosRequisicao.DadosAtividade(
                        nome = atividade.nome,
                        descricao = atividade.descricao,
                        prazoFormatado = formatarData(atividade.dataPrazo),
                        nomePilar = pilar.nome,
                        responsaveis = responsaveis
                    )
                }


                else -> null
            }

            notificacao.dadosAcaoOuAtividade = dados
            resultado.postValue(notificacao)
        }

        return resultado
    }

    private fun formatarData(data: Date): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        return sdf.format(data)
    }
}

