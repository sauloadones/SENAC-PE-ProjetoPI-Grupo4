package com.example.appsenkaspi

import androidx.room.*

import java.util.*

@Entity(
    tableName = "requisicoes",
    foreignKeys = [
        ForeignKey(
            entity = FuncionarioEntity::class,
            parentColumns = ["id"],
            childColumns = ["idSolicitante"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = FuncionarioEntity::class,
            parentColumns = ["id"],
            childColumns = ["idDestinatario"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["idSolicitante"]),
        Index(value = ["idDestinatario"])
    ]
)
data class RequisicaoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    @ColumnInfo(name = "tipo")
    val tipo: TipoRequisicao,

    @ColumnInfo(name = "status")
    val status: StatusRequisicao = StatusRequisicao.PENDENTE,

    @ColumnInfo(name = "idSolicitante")
    val idSolicitante: Int,

    @ColumnInfo(name = "idDestinatario")
    val idDestinatario: Int? = null, // Ex: Coordenador responsável

    @ColumnInfo(name = "idReferencia")
    val idReferencia: Int? = null, // Acao ou Atividade

    @ColumnInfo(name = "dataCriacao")
    val dataCriacao: Date = Date()
)
